package com.example.rxkotlin3.data

data class MovieItem(val moviePicture: Int,
                     val name:String,val genre:String,val year :Int)